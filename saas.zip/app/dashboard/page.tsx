// app/dashboard/page.tsx
import dbConnect from '@/lib/db';
import { getCurrentBusiness } from '@/lib/currentBusiness';
import DashboardClient from './DashboardClient';
import { redirect } from 'next/navigation';

export default async function DashboardPage() {
  await dbConnect();

  const business = await getCurrentBusiness();

  // Si por alguna razón el usuario no tiene negocio asignado
  if (!business) {
    // Podés mandarlo a una pantalla de “crear negocio”
    redirect('/onboarding'); // o la ruta que tengas
  }

  return (
    <DashboardClient
      businessName={business.name}
    />
  );
}
